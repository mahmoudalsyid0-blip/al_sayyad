import { CartItem, CheckoutLead, Product } from "./types";

// Store owner's WhatsApp number in international format, no + or leading zeros.
// Move this to an environment variable (NEXT_PUBLIC_WHATSAPP_NUMBER) before deploying.
export const STORE_WHATSAPP_NUMBER =
  process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "201000000000";

function formatCurrency(value: number) {
  return `EGP ${value.toLocaleString("en-US")}`;
}

/**
 * Builds a single-product "Book via WhatsApp" message, as required by the
 * PDF's WhatsApp Checkout System: pre-formatted message containing product
 * details, prices, and an image link, sent straight to the store owner.
 */
export function buildProductWhatsAppUrl(product: Product): string {
  const lines = [
    `Hello Al Sayyad, I'd like to book this item:`,
    ``,
    `*${product.name}*`,
    `Category: ${product.category}`,
    `Price: ${formatCurrency(product.price)}`,
    product.size ? `Size: ${product.size}` : null,
    product.color ? `Color: ${product.color}` : null,
    ``,
    `Image: ${product.imageUrl}`,
  ].filter(Boolean);

  const text = encodeURIComponent(lines.join("\n"));
  return `https://wa.me/${STORE_WHATSAPP_NUMBER}?text=${text}`;
}

/**
 * Builds a full-cart checkout message once the customer has bundled several
 * items and submitted the lead-capture popup (PDF Phase 4).
 */
export function buildCartWhatsAppUrl(
  items: CartItem[],
  lead: CheckoutLead
): string {
  const itemLines = items.map(
    (item) =>
      `• ${item.product.name} x${item.quantity} — ${formatCurrency(
        item.product.price * item.quantity
      )}`
  );

  const total = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );

  const lines = [
    `Hello Al Sayyad, I'd like to place an order.`,
    ``,
    `*Order summary*`,
    ...itemLines,
    ``,
    `Total: ${formatCurrency(total)}`,
    ``,
    `*Customer details*`,
    `Name: ${lead.name}`,
    `Phone: ${lead.phone}`,
    `Address: ${lead.address}`,
  ];

  const text = encodeURIComponent(lines.join("\n"));
  return `https://wa.me/${STORE_WHATSAPP_NUMBER}?text=${text}`;
}
