// Firebase bootstrap — Path 1 tech stack from the PDF (Firestore + Storage + Auth).
// Fill in the config from your Firebase console and set the env vars below
// before wiring the Admin Panel CRUD forms and image uploads to live data.
//
// npm install firebase
//
// import { initializeApp, getApps } from "firebase/app";
// import { getFirestore } from "firebase/firestore";
// import { getStorage } from "firebase/storage";
// import { getAuth } from "firebase/auth";
//
// const firebaseConfig = {
//   apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
//   authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
//   projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
//   storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
//   messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
//   appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
// };
//
// const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
// export const db = getFirestore(app);
// export const storage = getStorage(app);
// export const auth = getAuth(app);
//
// Firestore collection: "products"
//   { name, price, category, description, imageUrl, stock, size, color, featured, createdAt }
//
// Until Firebase is connected, the Admin Panel and storefront both read/write
// through lib/products.ts + localStorage so the whole flow works end-to-end
// in the browser during development.

export const FIREBASE_CONNECTED = false;
