import { Product } from "./types";

// In production this collection is read from Firebase Firestore
// (see /lib/firebase.ts placeholder + Admin Panel CRUD forms).
// Seed data here lets the storefront render immediately in development.

export const PRODUCTS: Product[] = [
  {
    id: "p001",
    name: "Tailored Wool Overcoat",
    price: 2450,
    category: "Men",
    description: "Structured double-breasted overcoat, hand-finished lapels.",
    imageUrl:
      "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=800&q=80",
    stock: "in_stock",
    size: "M / L / XL",
    color: "Charcoal",
    featured: true,
    createdAt: "2026-06-28",
  },
  {
    id: "p002",
    name: "Silk Wrap Blouse",
    price: 980,
    category: "Women",
    description: "Fluid silk blouse with a soft draped neckline.",
    imageUrl:
      "https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=800&q=80",
    stock: "in_stock",
    size: "S / M / L",
    color: "Ivory",
    featured: true,
    createdAt: "2026-06-30",
  },
  {
    id: "p003",
    name: "Kids Corduroy Dungarees",
    price: 540,
    category: "Kids",
    description: "Durable corduroy dungarees with brass button fastenings.",
    imageUrl:
      "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=800&q=80",
    stock: "in_stock",
    size: "2-6 yrs",
    color: "Rust",
    createdAt: "2026-06-25",
  },
  {
    id: "p004",
    name: "Merino Crewneck Sweater",
    price: 1150,
    category: "Men",
    description: "Fine-gauge merino knit, ribbed cuffs and hem.",
    imageUrl:
      "https://images.unsplash.com/photo-1614975059251-992f11792b9f?w=800&q=80",
    stock: "out_of_stock",
    size: "S / M / L / XL",
    color: "Bottle Green",
    createdAt: "2026-06-18",
  },
  {
    id: "p005",
    name: "Pleated Midi Skirt",
    price: 760,
    category: "Women",
    description: "Sun-pleated midi skirt in a fluid satin finish.",
    imageUrl:
      "https://images.unsplash.com/photo-1583496661160-fb5886a13d74?w=800&q=80",
    stock: "in_stock",
    size: "XS / S / M",
    color: "Blush",
    featured: true,
    createdAt: "2026-07-01",
  },
  {
    id: "p006",
    name: "Kids Rain Slicker",
    price: 420,
    category: "Kids",
    description: "Lightweight waterproof slicker with taped seams.",
    imageUrl:
      "https://images.unsplash.com/photo-1622290291165-d5dd7e5a7d10?w=800&q=80",
    stock: "in_stock",
    size: "3-8 yrs",
    color: "Marigold",
    createdAt: "2026-06-20",
  },
  {
    id: "p007",
    name: "Linen Blend Blazer",
    price: 1890,
    category: "Men",
    description: "Unstructured linen blazer, breathable summer weight.",
    imageUrl:
      "https://images.unsplash.com/photo-1598808503746-f34c53b9323e?w=800&q=80",
    stock: "in_stock",
    size: "M / L / XL",
    color: "Sand",
    createdAt: "2026-06-29",
  },
  {
    id: "p008",
    name: "Cashmere Wrap Coat",
    price: 3200,
    category: "Women",
    description: "Belted cashmere coat with a relaxed silhouette.",
    imageUrl:
      "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=800&q=80",
    stock: "in_stock",
    size: "S / M / L",
    color: "Camel",
    featured: true,
    createdAt: "2026-07-02",
  },
];

export function getLatest(products: Product[] = PRODUCTS) {
  return [...products].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function getFeatured(products: Product[] = PRODUCTS) {
  return products.filter((p) => p.featured);
}
