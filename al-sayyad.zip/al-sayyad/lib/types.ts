// Product data structure — matches PDF Phase 1 spec:
// Name, Price, Category, Description, ImageURL, Stock status

export type Category = "Men" | "Women" | "Kids";

export type StockStatus = "in_stock" | "out_of_stock";

export interface Product {
  id: string;
  name: string;
  price: number;
  category: Category;
  description: string;
  imageUrl: string;
  stock: StockStatus;
  size?: string;
  color?: string;
  featured?: boolean;
  createdAt: string; // ISO date, used for "أحدث الإضافات" (latest additions) sort
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface CheckoutLead {
  name: string;
  phone: string;
  address: string;
}
