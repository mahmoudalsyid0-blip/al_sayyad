"use client";

import { useState, FormEvent } from "react";
import { Category, Product, StockStatus } from "@/lib/types";

type FormState = Omit<Product, "id" | "createdAt">;

const EMPTY_FORM: FormState = {
  name: "",
  price: 0,
  category: "Men",
  description: "",
  imageUrl: "",
  stock: "in_stock",
  size: "",
  color: "",
  featured: false,
};

export function ProductForm({
  initial,
  onSubmit,
  onCancel,
}: {
  initial?: Product;
  onSubmit: (values: FormState) => void;
  onCancel?: () => void;
}) {
  const [form, setForm] = useState<FormState>(initial ?? EMPTY_FORM);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit(form);
    if (!initial) setForm(EMPTY_FORM);
  };

  // Configure file upload handlers to commit imagery to Firebase Storage
  // and store the returned download URL here (PDF Phase 3). For now this
  // accepts a direct image URL so the flow works without cloud storage.
  return (
    <form
      onSubmit={handleSubmit}
      className="grid grid-cols-1 gap-4 rounded-card border border-stone bg-white/60 p-6 dark:border-ink/60 dark:bg-white/5 sm:grid-cols-2"
    >
      <div className="sm:col-span-2">
        <label className="eyebrow mb-1 block">Title</label>
        <input
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full rounded-card border border-stone bg-transparent px-3 py-2 text-sm focus:border-brass dark:border-ink/60"
        />
      </div>

      <div>
        <label className="eyebrow mb-1 block">Price (EGP)</label>
        <input
          required
          type="number"
          min={0}
          value={form.price}
          onChange={(e) =>
            setForm({ ...form, price: Number(e.target.value) })
          }
          className="w-full rounded-card border border-stone bg-transparent px-3 py-2 text-sm focus:border-brass dark:border-ink/60"
        />
      </div>

      <div>
        <label className="eyebrow mb-1 block">Category</label>
        <select
          value={form.category}
          onChange={(e) =>
            setForm({ ...form, category: e.target.value as Category })
          }
          className="w-full rounded-card border border-stone bg-transparent px-3 py-2 text-sm focus:border-brass dark:border-ink/60"
        >
          <option value="Men">Men</option>
          <option value="Women">Women</option>
          <option value="Kids">Kids</option>
        </select>
      </div>

      <div className="sm:col-span-2">
        <label className="eyebrow mb-1 block">Description</label>
        <textarea
          required
          rows={2}
          value={form.description}
          onChange={(e) =>
            setForm({ ...form, description: e.target.value })
          }
          className="w-full rounded-card border border-stone bg-transparent px-3 py-2 text-sm focus:border-brass dark:border-ink/60"
        />
      </div>

      <div className="sm:col-span-2">
        <label className="eyebrow mb-1 block">Image URL</label>
        <input
          required
          value={form.imageUrl}
          onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
          placeholder="https://…"
          className="w-full rounded-card border border-stone bg-transparent px-3 py-2 text-sm focus:border-brass dark:border-ink/60"
        />
      </div>

      <div>
        <label className="eyebrow mb-1 block">Size</label>
        <input
          value={form.size}
          onChange={(e) => setForm({ ...form, size: e.target.value })}
          placeholder="S / M / L"
          className="w-full rounded-card border border-stone bg-transparent px-3 py-2 text-sm focus:border-brass dark:border-ink/60"
        />
      </div>

      <div>
        <label className="eyebrow mb-1 block">Color</label>
        <input
          value={form.color}
          onChange={(e) => setForm({ ...form, color: e.target.value })}
          className="w-full rounded-card border border-stone bg-transparent px-3 py-2 text-sm focus:border-brass dark:border-ink/60"
        />
      </div>

      <div>
        <label className="eyebrow mb-1 block">Stock status</label>
        <select
          value={form.stock}
          onChange={(e) =>
            setForm({ ...form, stock: e.target.value as StockStatus })
          }
          className="w-full rounded-card border border-stone bg-transparent px-3 py-2 text-sm focus:border-brass dark:border-ink/60"
        >
          <option value="in_stock">In Stock</option>
          <option value="out_of_stock">Out of Stock</option>
        </select>
      </div>

      <label className="flex items-center gap-2 self-end text-sm">
        <input
          type="checkbox"
          checked={!!form.featured}
          onChange={(e) => setForm({ ...form, featured: e.target.checked })}
          className="h-4 w-4 accent-brass"
        />
        Feature on homepage
      </label>

      <div className="flex gap-3 pt-2 sm:col-span-2">
        <button
          type="submit"
          className="rounded-card bg-ink px-6 py-2.5 text-sm font-semibold text-bone hover:bg-brassDark dark:bg-bone dark:text-ink"
        >
          {initial ? "Save changes" : "Add product"}
        </button>
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="rounded-card border border-stone px-6 py-2.5 text-sm text-ink/70 dark:border-ink/60 dark:text-bone/70"
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
