import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-stone bg-bone dark:border-ink/60 dark:bg-ink">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-3 md:px-8">
        <div>
          <p className="font-display text-xl text-ink dark:text-bone">
            Al Sayyad
          </p>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-ink/60 dark:text-bone/60">
            A modern clothing house for Men, Women & Kids — tailored pieces,
            booked instantly, delivered with care.
          </p>
        </div>

        <div>
          <p className="eyebrow mb-4">Store</p>
          <nav className="flex flex-col gap-2 text-sm">
            <Link href="/" className="text-ink/70 hover:text-brass dark:text-bone/70">
              Home
            </Link>
            <Link href="/about" className="text-ink/70 hover:text-brass dark:text-bone/70">
              About
            </Link>
            <Link href="/#collection" className="text-ink/70 hover:text-brass dark:text-bone/70">
              Collection
            </Link>
          </nav>
        </div>

        <div>
          <p className="eyebrow mb-4">Support</p>
          <nav className="flex flex-col gap-2 text-sm">
            <Link href="/contact" className="text-ink/70 hover:text-brass dark:text-bone/70">
              Contact Us
            </Link>
            <Link href="/admin/login" className="text-ink/70 hover:text-brass dark:text-bone/70">
              Admin Login
            </Link>
          </nav>
        </div>
      </div>

      <div className="border-t border-stone py-5 dark:border-ink/60">
        <p className="text-center text-xs text-ink/50 dark:text-bone/50">
          © 2026 Al Sayyad. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
