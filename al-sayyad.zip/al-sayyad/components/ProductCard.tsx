"use client";

import Image from "next/image";
import { Product } from "@/lib/types";
import { buildProductWhatsAppUrl } from "@/lib/whatsapp";
import { useCart } from "@/context/CartContext";

export function ProductCard({ product }: { product: Product }) {
  const { addItem } = useCart();
  const outOfStock = product.stock === "out_of_stock";

  return (
    <article className="group animate-fadeUp overflow-hidden rounded-card border border-stone bg-white/60 transition-shadow hover:shadow-lg dark:border-ink/60 dark:bg-white/5">
      <div className="relative aspect-[4/5] overflow-hidden bg-stone/40">
        <Image
          src={product.imageUrl}
          alt={product.name}
          fill
          sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
          className={`object-cover transition-transform duration-500 group-hover:scale-105 ${
            outOfStock ? "grayscale" : ""
          }`}
        />
        <span className="absolute left-3 top-3 rounded-card bg-ink/85 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest2 text-bone">
          {product.category}'s Clothing
        </span>
        {outOfStock && (
          <span className="absolute right-3 top-3 rounded-card bg-rust px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-bone">
            Out of Stock
          </span>
        )}
      </div>

      <div className="space-y-2 p-4">
        <h3 className="font-display text-lg leading-snug text-ink dark:text-bone">
          {product.name}
        </h3>
        <p className="line-clamp-2 text-sm text-ink/60 dark:text-bone/60">
          {product.description}
        </p>
        <div className="flex items-center justify-between pt-1">
          <span className="rounded-card border border-brass/40 bg-brass/10 px-2.5 py-1 font-mono text-sm font-semibold text-brassDark dark:text-brass">
            EGP {product.price.toLocaleString("en-US")}
          </span>
          <button
            onClick={() => addItem(product)}
            disabled={outOfStock}
            className="text-xs font-medium text-ink/50 underline decoration-stone underline-offset-4 transition-colors hover:text-brass disabled:cursor-not-allowed disabled:opacity-40 dark:text-bone/50"
          >
            Add to cart
          </button>
        </div>

        <a
          href={outOfStock ? undefined : buildProductWhatsAppUrl(product)}
          target="_blank"
          rel="noopener noreferrer"
          aria-disabled={outOfStock}
          className={`mt-2 flex w-full items-center justify-center gap-2 rounded-card px-4 py-2.5 text-sm font-semibold transition-colors ${
            outOfStock
              ? "pointer-events-none bg-stone text-ink/40"
              : "bg-ink text-bone hover:bg-brassDark dark:bg-bone dark:text-ink dark:hover:bg-brass"
          }`}
        >
          Book via WhatsApp
        </a>
      </div>
    </article>
  );
}
