"use client";

import Image from "next/image";
import Link from "next/link";
import { Product } from "@/lib/types";

export function FeaturedSection({ products }: { products: Product[] }) {
  if (products.length === 0) return null;

  return (
    <section className="border-t border-stone bg-ink py-14 dark:border-ink/60">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <p className="eyebrow text-brass">Curated by Al Sayyad</p>
        <h2 className="mb-1 font-display text-3xl text-bone">
          Selected Pieces
        </h2>
        <div className="stitch-rule mb-8 w-24" />

        <div className="flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2">
          {products.map((product) => (
            <Link
              key={product.id}
              href={`#${product.id}`}
              className="group relative w-56 shrink-0 snap-start overflow-hidden rounded-card sm:w-64"
            >
              <div className="relative aspect-[4/5]">
                <Image
                  src={product.imageUrl}
                  alt={product.name}
                  fill
                  sizes="256px"
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/10 to-transparent" />
              </div>
              <div className="absolute inset-x-0 bottom-0 p-4">
                <p className="font-display text-base text-bone">
                  {product.name}
                </p>
                <p className="font-mono text-xs text-brass">
                  EGP {product.price.toLocaleString("en-US")}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
