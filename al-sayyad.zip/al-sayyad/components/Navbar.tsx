"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useCart } from "@/context/CartContext";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export function Navbar() {
  const { totalItems } = useCart();
  const [dark, setDark] = useState(false);
  const [lang, setLang] = useState<"EN" | "AR">("EN");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <header className="sticky top-0 z-40 border-b border-stone bg-bone/90 backdrop-blur dark:bg-ink/90 dark:border-ink/60">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-8">
        <Link
          href="/"
          className="font-display text-2xl font-bold tracking-wide text-ink dark:text-bone"
        >
          Al Sayyad
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-ink/70 transition-colors hover:text-brass dark:text-bone/70"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setLang(lang === "EN" ? "AR" : "EN")}
            aria-label="Switch language"
            className="rounded-card border border-stone px-2.5 py-1.5 font-mono text-xs text-ink/70 transition-colors hover:border-brass hover:text-brass dark:border-ink/60 dark:text-bone/70"
          >
            {lang}
          </button>
          <button
            onClick={() => setDark(!dark)}
            aria-label="Switch theme"
            className="rounded-card border border-stone px-2.5 py-1.5 text-xs text-ink/70 transition-colors hover:border-brass hover:text-brass dark:border-ink/60 dark:text-bone/70"
          >
            {dark ? "Light" : "Dark"}
          </button>
          <Link
            href="/cart"
            className="relative rounded-card border border-stone px-3 py-1.5 text-xs font-medium text-ink/80 transition-colors hover:border-brass hover:text-brass dark:border-ink/60 dark:text-bone/80"
          >
            Cart
            {totalItems > 0 && (
              <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-brass text-[11px] font-semibold text-bone">
                {totalItems}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}
