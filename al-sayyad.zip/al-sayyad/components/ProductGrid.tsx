"use client";

import { useMemo, useState } from "react";
import { Product } from "@/lib/types";
import { getLatest } from "@/lib/products";
import { ProductCard } from "./ProductCard";
import { CategoryTabs, TabValue } from "./CategoryTabs";

const PAGE_SIZE = 8;

export function ProductGrid({ products }: { products: Product[] }) {
  const [tab, setTab] = useState<TabValue>("All");
  const [query, setQuery] = useState("");
  const [visible, setVisible] = useState(PAGE_SIZE);

  const filtered = useMemo(() => {
    const latest = getLatest(products);
    return latest.filter((p) => {
      const matchesTab = tab === "All" || p.category === tab;
      const matchesQuery = p.name
        .toLowerCase()
        .includes(query.trim().toLowerCase());
      return matchesTab && matchesQuery;
    });
  }, [products, tab, query]);

  const paged = filtered.slice(0, visible);
  const hasMore = visible < filtered.length;

  return (
    <section id="collection">
      <CategoryTabs
        active={tab}
        onChange={(t) => {
          setTab(t);
          setVisible(PAGE_SIZE);
        }}
      />

      <div className="mx-auto max-w-7xl px-5 py-10 md:px-8">
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="eyebrow">Latest Additions</p>
            <h2 className="font-display text-3xl text-ink dark:text-bone">
              The New Arrivals
            </h2>
          </div>
          <input
            type="search"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setVisible(PAGE_SIZE);
            }}
            placeholder="Search products…"
            className="w-full max-w-xs rounded-card border border-stone bg-white/60 px-4 py-2.5 text-sm text-ink placeholder:text-ink/40 focus:border-brass dark:border-ink/60 dark:bg-white/5 dark:text-bone"
          />
        </div>

        {paged.length === 0 ? (
          <p className="rounded-card border border-dashed border-stone py-16 text-center text-ink/50 dark:border-ink/60 dark:text-bone/50">
            No pieces match that search yet — try another name or category.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {paged.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        {hasMore && (
          <div className="mt-10 flex justify-center">
            <button
              onClick={() => setVisible((v) => v + PAGE_SIZE)}
              className="rounded-card border border-ink px-8 py-3 text-sm font-semibold uppercase tracking-widest2 text-ink transition-colors hover:bg-ink hover:text-bone dark:border-bone dark:text-bone dark:hover:bg-bone dark:hover:text-ink"
            >
              Load More
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
