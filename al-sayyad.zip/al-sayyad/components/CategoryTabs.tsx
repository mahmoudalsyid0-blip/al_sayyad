"use client";

import { Category } from "@/lib/types";

export type TabValue = "All" | Category;

const TABS: TabValue[] = ["All", "Men", "Women", "Kids"];

export function CategoryTabs({
  active,
  onChange,
}: {
  active: TabValue;
  onChange: (tab: TabValue) => void;
}) {
  return (
    <div className="border-b border-stone bg-bone/70 backdrop-blur dark:bg-ink/70 dark:border-ink/60">
      <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-5 md:px-8">
        {TABS.map((tab) => {
          const isActive = tab === active;
          return (
            <button
              key={tab}
              onClick={() => onChange(tab)}
              className={`relative whitespace-nowrap px-4 py-3 text-sm font-medium transition-colors ${
                isActive
                  ? "text-brass"
                  : "text-ink/60 hover:text-ink dark:text-bone/60 dark:hover:text-bone"
              }`}
            >
              {tab}
              {isActive && (
                <span className="absolute inset-x-3 bottom-0 h-[2px] bg-brass" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
