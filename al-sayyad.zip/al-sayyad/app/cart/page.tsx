"use client";

import { useState } from "react";
import Image from "next/image";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useCart } from "@/context/CartContext";
import { buildCartWhatsAppUrl } from "@/lib/whatsapp";
import { CheckoutLead } from "@/lib/types";

export default function CartPage() {
  const { items, updateQuantity, removeItem, totalPrice } = useCart();
  const [lead, setLead] = useState<CheckoutLead>({
    name: "",
    phone: "",
    address: "",
  });

  const canCheckout = items.length > 0 && lead.name && lead.phone && lead.address;

  return (
    <main className="min-h-screen bg-bone dark:bg-ink">
      <Navbar />

      <section className="mx-auto max-w-4xl px-5 py-14 md:px-8">
        <p className="eyebrow">Your Selection</p>
        <h1 className="mt-2 font-display text-4xl text-ink dark:text-bone">
          Cart
        </h1>

        {items.length === 0 ? (
          <p className="mt-10 rounded-card border border-dashed border-stone py-16 text-center text-ink/50 dark:border-ink/60 dark:text-bone/50">
            Your cart is empty — browse the collection and add a piece.
          </p>
        ) : (
          <div className="mt-8 space-y-4">
            {items.map(({ product, quantity }) => (
              <div
                key={product.id}
                className="flex items-center gap-4 rounded-card border border-stone p-4 dark:border-ink/60"
              >
                <div className="relative h-20 w-16 shrink-0 overflow-hidden rounded-card bg-stone/40">
                  <Image
                    src={product.imageUrl}
                    alt={product.name}
                    fill
                    sizes="64px"
                    className="object-cover"
                  />
                </div>
                <div className="flex-1">
                  <p className="font-display text-base text-ink dark:text-bone">
                    {product.name}
                  </p>
                  <p className="font-mono text-sm text-brassDark dark:text-brass">
                    EGP {product.price.toLocaleString("en-US")}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateQuantity(product.id, quantity - 1)}
                    className="h-8 w-8 rounded-card border border-stone text-ink/70 hover:border-brass hover:text-brass dark:border-ink/60 dark:text-bone/70"
                  >
                    −
                  </button>
                  <span className="w-6 text-center text-sm">{quantity}</span>
                  <button
                    onClick={() => updateQuantity(product.id, quantity + 1)}
                    className="h-8 w-8 rounded-card border border-stone text-ink/70 hover:border-brass hover:text-brass dark:border-ink/60 dark:text-bone/70"
                  >
                    +
                  </button>
                </div>
                <button
                  onClick={() => removeItem(product.id)}
                  className="text-xs text-ink/40 underline hover:text-rust"
                >
                  Remove
                </button>
              </div>
            ))}

            <div className="flex items-center justify-between border-t border-stone pt-4 dark:border-ink/60">
              <span className="font-medium text-ink dark:text-bone">Total</span>
              <span className="font-mono text-lg font-semibold text-brassDark dark:text-brass">
                EGP {totalPrice.toLocaleString("en-US")}
              </span>
            </div>

            <div className="mt-8 space-y-3 rounded-card border border-stone p-5 dark:border-ink/60">
              <p className="eyebrow">Delivery details</p>
              <input
                placeholder="Full name"
                value={lead.name}
                onChange={(e) => setLead({ ...lead, name: e.target.value })}
                className="w-full rounded-card border border-stone bg-white/60 px-4 py-2.5 text-sm focus:border-brass dark:border-ink/60 dark:bg-white/5 dark:text-bone"
              />
              <input
                placeholder="Phone number"
                value={lead.phone}
                onChange={(e) => setLead({ ...lead, phone: e.target.value })}
                className="w-full rounded-card border border-stone bg-white/60 px-4 py-2.5 text-sm focus:border-brass dark:border-ink/60 dark:bg-white/5 dark:text-bone"
              />
              <input
                placeholder="Shipping address"
                value={lead.address}
                onChange={(e) => setLead({ ...lead, address: e.target.value })}
                className="w-full rounded-card border border-stone bg-white/60 px-4 py-2.5 text-sm focus:border-brass dark:border-ink/60 dark:bg-white/5 dark:text-bone"
              />

              <a
                href={canCheckout ? buildCartWhatsAppUrl(items, lead) : undefined}
                target="_blank"
                rel="noopener noreferrer"
                aria-disabled={!canCheckout}
                className={`mt-2 flex w-full items-center justify-center rounded-card px-4 py-3 text-sm font-semibold transition-colors ${
                  canCheckout
                    ? "bg-ink text-bone hover:bg-brassDark dark:bg-bone dark:text-ink dark:hover:bg-brass"
                    : "pointer-events-none bg-stone text-ink/40"
                }`}
              >
                Send Order via WhatsApp
              </a>
            </div>
          </div>
        )}
      </section>

      <Footer />
    </main>
  );
}
