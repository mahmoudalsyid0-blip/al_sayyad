"use client";

import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ProductGrid } from "@/components/ProductGrid";
import { FeaturedSection } from "@/components/FeaturedSection";
import { useProducts } from "@/context/ProductsContext";
import { getFeatured } from "@/lib/products";

export default function HomePage() {
  const { products } = useProducts();

  return (
    <main className="min-h-screen bg-bone dark:bg-ink">
      <Navbar />

      <section className="border-b border-stone px-5 py-16 text-center dark:border-ink/60 md:py-24">
        <p className="eyebrow">Men · Women · Kids</p>
        <h1 className="mx-auto mt-3 max-w-2xl font-display text-4xl leading-tight text-ink dark:text-bone md:text-5xl">
          Tailored pieces, booked in one tap.
        </h1>
        <p className="mx-auto mt-4 max-w-md text-sm text-ink/60 dark:text-bone/60">
          Browse the collection and send a booking straight to our WhatsApp —
          no account, no friction.
        </p>
      </section>

      <ProductGrid products={products} />
      <FeaturedSection products={getFeatured(products)} />

      <Footer />
    </main>
  );
}
