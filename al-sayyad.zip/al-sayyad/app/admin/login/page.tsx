"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";

// Placeholder auth gate — swap for Firebase Auth (email/password or
// custom claims) per the PDF's "secure Admin Login" requirement.
// Demo credentials: admin / alsayyad2026
const DEMO_USER = "admin";
const DEMO_PASS = "alsayyad2026";
const SESSION_KEY = "al-sayyad-admin-session";

export default function AdminLoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (username === DEMO_USER && password === DEMO_PASS) {
      window.sessionStorage.setItem(SESSION_KEY, "true");
      router.push("/admin/dashboard");
    } else {
      setError("Incorrect username or password.");
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-ink px-5">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm rounded-card border border-bone/10 bg-white/5 p-8"
      >
        <p className="eyebrow text-brass">Al Sayyad</p>
        <h1 className="mt-1 font-display text-2xl text-bone">
          Admin Dashboard
        </h1>
        <p className="mt-2 text-sm text-bone/50">
          Sign in to manage products and bookings.
        </p>

        <div className="mt-6 space-y-3">
          <input
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full rounded-card border border-bone/20 bg-transparent px-4 py-2.5 text-sm text-bone placeholder:text-bone/40 focus:border-brass"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-card border border-bone/20 bg-transparent px-4 py-2.5 text-sm text-bone placeholder:text-bone/40 focus:border-brass"
          />
        </div>

        {error && <p className="mt-3 text-xs text-rust">{error}</p>}

        <button
          type="submit"
          className="mt-6 w-full rounded-card bg-brass px-4 py-3 text-sm font-semibold text-ink transition-colors hover:bg-brassDark"
        >
          Sign In
        </button>

        <p className="mt-4 text-center text-xs text-bone/30">
          Demo credentials — admin / alsayyad2026
        </p>
      </form>
    </main>
  );
}
