"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { useProducts } from "@/context/ProductsContext";
import { ProductForm } from "@/components/admin/ProductForm";
import { Product } from "@/lib/types";

const SESSION_KEY = "al-sayyad-admin-session";

export default function AdminDashboardPage() {
  const router = useRouter();
  const { products, addProduct, updateProduct, deleteProduct, toggleStock } =
    useProducts();
  const [checking, setChecking] = useState(true);
  const [editing, setEditing] = useState<Product | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    const authed = window.sessionStorage.getItem(SESSION_KEY);
    if (!authed) {
      router.replace("/admin/login");
    } else {
      setChecking(false);
    }
  }, [router]);

  const handleLogout = () => {
    window.sessionStorage.removeItem(SESSION_KEY);
    router.push("/admin/login");
  };

  if (checking) return null;

  return (
    <main className="min-h-screen bg-bone dark:bg-ink">
      <header className="border-b border-stone bg-ink dark:border-ink/60">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 md:px-8">
          <div>
            <p className="eyebrow text-brass">Al Sayyad</p>
            <h1 className="font-display text-2xl text-bone">
              Al Sayyad Admin Dashboard
            </h1>
          </div>
          <button
            onClick={handleLogout}
            className="rounded-card border border-bone/20 px-4 py-2 text-sm text-bone/70 hover:border-brass hover:text-brass"
          >
            Log out
          </button>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-5 py-10 md:px-8">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="font-display text-2xl text-ink dark:text-bone">
            Products ({products.length})
          </h2>
          <button
            onClick={() => {
              setShowAddForm(!showAddForm);
              setEditing(null);
            }}
            className="rounded-card bg-ink px-5 py-2.5 text-sm font-semibold text-bone hover:bg-brassDark dark:bg-bone dark:text-ink"
          >
            {showAddForm ? "Close" : "+ Add product"}
          </button>
        </div>

        {showAddForm && (
          <div className="mb-8">
            <ProductForm
              onSubmit={(values) => {
                addProduct(values);
                setShowAddForm(false);
              }}
              onCancel={() => setShowAddForm(false)}
            />
          </div>
        )}

        {editing && (
          <div className="mb-8">
            <ProductForm
              initial={editing}
              onSubmit={(values) => {
                updateProduct(editing.id, values);
                setEditing(null);
              }}
              onCancel={() => setEditing(null)}
            />
          </div>
        )}

        <div className="overflow-x-auto rounded-card border border-stone dark:border-ink/60">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-stone bg-stone/20 text-xs uppercase tracking-wide text-ink/60 dark:border-ink/60 dark:bg-white/5 dark:text-bone/60">
              <tr>
                <th className="px-4 py-3">Product</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Price</th>
                <th className="px-4 py-3">Stock</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr
                  key={product.id}
                  className="border-b border-stone last:border-0 dark:border-ink/60"
                >
                  <td className="flex items-center gap-3 px-4 py-3">
                    <div className="relative h-12 w-10 shrink-0 overflow-hidden rounded-card bg-stone/40">
                      <Image
                        src={product.imageUrl}
                        alt={product.name}
                        fill
                        sizes="40px"
                        className="object-cover"
                      />
                    </div>
                    <span className="font-medium text-ink dark:text-bone">
                      {product.name}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-ink/70 dark:text-bone/70">
                    {product.category}
                  </td>
                  <td className="px-4 py-3 font-mono text-brassDark dark:text-brass">
                    EGP {product.price.toLocaleString("en-US")}
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => toggleStock(product.id)}
                      className={`rounded-card px-2.5 py-1 text-xs font-semibold ${
                        product.stock === "in_stock"
                          ? "bg-brass/15 text-brassDark dark:text-brass"
                          : "bg-rust/15 text-rust"
                      }`}
                    >
                      {product.stock === "in_stock"
                        ? "In Stock"
                        : "Out of Stock"}
                    </button>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => {
                        setEditing(product);
                        setShowAddForm(false);
                      }}
                      className="mr-3 text-ink/60 underline hover:text-brass dark:text-bone/60"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => deleteProduct(product.id)}
                      className="text-rust underline"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
