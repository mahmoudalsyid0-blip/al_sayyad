import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function ContactPage() {
  return (
    <main className="min-h-screen bg-bone dark:bg-ink">
      <Navbar />
      <section className="mx-auto max-w-2xl px-5 py-20 md:px-8">
        <p className="eyebrow">Contact</p>
        <h1 className="mt-2 font-display text-4xl text-ink dark:text-bone">
          Talk to Al Sayyad
        </h1>
        <p className="mt-6 text-ink/70 dark:text-bone/70">
          The fastest way to reach us is the "Book via WhatsApp" button on
          any product — it goes straight to our team. For anything else,
          email hello@alsayyad.store.
        </p>
      </section>
      <Footer />
    </main>
  );
}
