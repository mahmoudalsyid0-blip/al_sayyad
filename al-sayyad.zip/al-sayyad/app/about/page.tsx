import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-bone dark:bg-ink">
      <Navbar />
      <section className="mx-auto max-w-3xl px-5 py-20 md:px-8">
        <p className="eyebrow">About</p>
        <h1 className="mt-2 font-display text-4xl text-ink dark:text-bone">
          The Al Sayyad house
        </h1>
        <p className="mt-6 text-ink/70 dark:text-bone/70">
          Al Sayyad is a modern clothing house serving Men, Women, and Kids,
          built around a simple idea: booking a piece should feel as direct
          as messaging a friend. Every item on the site can be reserved with
          a single tap straight to our WhatsApp — no accounts, no waiting.
        </p>
      </section>
      <Footer />
    </main>
  );
}
