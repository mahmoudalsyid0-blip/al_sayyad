"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import { Product, StockStatus } from "@/lib/types";
import { PRODUCTS as SEED_PRODUCTS } from "@/lib/products";

interface ProductsContextValue {
  products: Product[];
  addProduct: (product: Omit<Product, "id" | "createdAt">) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  toggleStock: (id: string) => void;
}

const ProductsContext = createContext<ProductsContextValue | undefined>(
  undefined
);
const STORAGE_KEY = "al-sayyad-products";

export function ProductsProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(SEED_PRODUCTS);
  const [hydrated, setHydrated] = useState(false);

  // Swap this localStorage layer for Firestore reads/writes once
  // lib/firebase.ts is wired up — the admin CRUD calls below stay identical.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setProducts(JSON.parse(raw));
    } catch {
      // ignore malformed storage, fall back to seed data
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
  }, [products, hydrated]);

  const addProduct: ProductsContextValue["addProduct"] = (product) => {
    const newProduct: Product = {
      ...product,
      id: `p${Date.now()}`,
      createdAt: new Date().toISOString().slice(0, 10),
    };
    setProducts((prev) => [newProduct, ...prev]);
  };

  const updateProduct: ProductsContextValue["updateProduct"] = (
    id,
    updates
  ) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const toggleStock = (id: string) => {
    setProducts((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              stock: (p.stock === "in_stock"
                ? "out_of_stock"
                : "in_stock") as StockStatus,
            }
          : p
      )
    );
  };

  return (
    <ProductsContext.Provider
      value={{
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleStock,
      }}
    >
      {children}
    </ProductsContext.Provider>
  );
}

export function useProducts() {
  const ctx = useContext(ProductsContext);
  if (!ctx)
    throw new Error("useProducts must be used within a ProductsProvider");
  return ctx;
}
