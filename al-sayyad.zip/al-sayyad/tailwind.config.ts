import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./context/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Al Sayyad design tokens — tailoring-house palette
        ink: "#14110F", // near-black charcoal, primary text/bg
        bone: "#F7F4EF", // warm cream surface
        stone: "#DDD6CB", // hairline borders / dividers
        brass: "#B08D57", // signature accent — stitched-gold
        brassDark: "#8C6F42",
        rust: "#6E2C2C", // secondary accent — out-of-stock / alerts
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      letterSpacing: {
        widest2: "0.28em",
      },
      borderRadius: {
        card: "2px",
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        fadeUp: "fadeUp 0.5s ease-out both",
      },
    },
  },
  plugins: [],
};
export default config;
