# Al Sayyad — E-commerce & Booking Platform

Next.js (App Router) + TypeScript + Tailwind CSS storefront for **Al Sayyad**,
built from the attached Project Requirements Document, with the layout
skeleton adapted from e5tarle.org's category-tab + card-grid structure.

## Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`. Admin dashboard: `/admin/login`
(demo credentials: `admin` / `alsayyad2026`).

## What's implemented

- **Storefront**: sticky navbar (logo, nav links, language/theme switcher),
  category tab filter (All / Men / Women / Kids) that filters client-side
  with no reload, product grid sorted by latest additions, smart search,
  "Load More" pagination, a featured-picks horizontal slider, and a
  3-column footer.
- **Product cards**: hover-zoom image, category badge, price tag, and a
  "Book via WhatsApp" button that opens a pre-filled `wa.me` message with
  the product name, price, size/color, and image link.
- **Local cart**: add/update/remove items, persisted to `localStorage`
  (`context/CartContext.tsx`), with a `/cart` page that collects
  name/phone/address and sends the whole order to WhatsApp.
- **Admin dashboard** (`/admin/dashboard`): password-gated, add/edit/delete
  products, toggle In Stock / Out of Stock, all persisted to `localStorage`
  via `context/ProductsContext.tsx` so the flow works end-to-end before
  Firebase is wired up.

## Wiring up the real backend (Path 1 from the PDF)

1. Create a Firebase project → enable **Firestore**, **Storage**, **Auth**.
2. Fill in `lib/firebase.ts` with your config and uncomment the SDK calls.
3. Replace the `localStorage` reads/writes in `context/ProductsContext.tsx`
   with Firestore `onSnapshot` / `addDoc` / `updateDoc` / `deleteDoc` calls —
   the function signatures (`addProduct`, `updateProduct`, `deleteProduct`,
   `toggleStock`) can stay identical, so no component above them needs to change.
4. Swap the admin login's demo check in `app/admin/login/page.tsx` for
   `signInWithEmailAndPassword` from Firebase Auth.
5. Add an image upload input to `components/admin/ProductForm.tsx` that
   pushes to Firebase Storage and writes the returned URL into `imageUrl`.

## Environment variables

```
NEXT_PUBLIC_WHATSAPP_NUMBER=201000000000   # store owner's WhatsApp, no + or leading 0
NEXT_PUBLIC_FIREBASE_API_KEY=…
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=…
NEXT_PUBLIC_FIREBASE_PROJECT_ID=…
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=…
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=…
NEXT_PUBLIC_FIREBASE_APP_ID=…
```

## Deployment

Push to a GitHub repo and import into Vercel (matches the PDF's Phase 5
hosting recommendation). Add the environment variables above in the
Vercel project settings before the first production build.

## Design tokens

| Token | Value | Use |
|---|---|---|
| `ink` | `#14110F` | Primary text / dark surfaces |
| `bone` | `#F7F4EF` | Primary background |
| `brass` | `#B08D57` | Signature accent — CTAs, active tab, price tags |
| `stone` | `#DDD6CB` | Hairline borders |
| `rust` | `#6E2C2C` | Out-of-stock / destructive actions |

Fonts: Playfair Display (display/headings), Manrope (body/UI), IBM Plex Mono
(prices, category badges, eyebrows).
